<?php
define('GLPI_SYSTEM_CRON', true);
define('GLPI_CONFIG_DIR', '/etc/glpi');
define('GLPI_VAR_DIR', '/var/lib/glpi');


